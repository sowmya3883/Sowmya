class PagesController < ApplicationController
    def about
        @title="about us"
        @content="this is the about page"
    end
end
